package com.example;

import com.example.Insert.Emp;

public interface EmpDao {
	public int insert(Emp emp);
	public int chnage(Emp emp);

}
